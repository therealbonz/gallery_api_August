#!/usr/bin/env bash
# ==============================================================================
# My-3D-Cube Linux Client Uninstaller
# ==============================================================================
set -e

RED="\033[0;31m"
GREEN="\033[0;32m"
CYAN="\033[0;36m"
NC="\033[0m"

echo -e "${CYAN}[*] Uninstalling My-3D-Cube Linux Client...${NC}"

# Stop systemd service if running
if command -v systemctl &> /dev/null; then
    systemctl --user stop my3dcube.service 2>/dev/null || true
    systemctl --user disable my3dcube.service 2>/dev/null || true
    rm -f "${HOME}/.config/systemd/user/my3dcube.service"
fi

# Stop any running process
pkill -f "my3dcube" 2>/dev/null || true

# Remove launcher, desktop file, icons, and venv
rm -f "${HOME}/.local/bin/my3dcube"
rm -f "${HOME}/.local/share/applications/my3dcube.desktop"
rm -f "${HOME}/.local/share/icons/hicolor/scalable/apps/my3dcube.svg"
rm -rf "${HOME}/.local/share/my3dcube"
rm -f "${HOME}/.config/autostart/my3dcube.desktop"

# Update desktop databases
command -v update-desktop-database &> /dev/null && update-desktop-database "${HOME}/.local/share/applications" 2>/dev/null || true

echo -e "${GREEN}[✓] My-3D-Cube has been cleanly removed from your system.${NC}"
