#!/usr/bin/env bash
# ==============================================================================
# My-3D-Cube Linux Client & Live Desktop Wallpaper Installer
# ==============================================================================
set -e

GREEN="\033[0;32m"
CYAN="\033[0;36m"
YELLOW="\033[1;33m"
RED="\033[0;31m"
NC="\033[0m"

echo -e "${CYAN}====================================================${NC}"
echo -e "${CYAN}   My-3D-Cube: Linux Client & Wallpaper Installer   ${NC}"
echo -e "${CYAN}====================================================${NC}"

# Check Python 3
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}[Error] Python 3 is required but was not found on your system.${NC}"
    echo "Please install python3 using your distribution's package manager and try again."
    exit 1
fi

PY_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo -e "${GREEN}[✓] Found Python ${PY_VERSION}${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_PREFIX="${HOME}/.local"
BIN_DIR="${INSTALL_PREFIX}/bin"
APPS_DIR="${INSTALL_PREFIX}/share/applications"
ICONS_DIR="${INSTALL_PREFIX}/share/icons/hicolor/scalable/apps"
VENV_DIR="${INSTALL_PREFIX}/share/my3dcube/venv"

mkdir -p "${BIN_DIR}"
mkdir -p "${APPS_DIR}"
mkdir -p "${ICONS_DIR}"
mkdir -p "$(dirname "${VENV_DIR}")"

# Create or reuse dedicated Python virtual environment
echo -e "${CYAN}[*] Setting up isolated Python environment in ${VENV_DIR}...${NC}"
if [ ! -d "${VENV_DIR}" ]; then
    python3 -m venv "${VENV_DIR}" --system-site-packages || {
        echo -e "${YELLOW}[!] Failed to create venv with --system-site-packages; trying standard venv...${NC}"
        python3 -m venv "${VENV_DIR}"
    }
fi

# Upgrade pip & install dependencies
echo -e "${CYAN}[*] Installing dependencies (PyQt6, PyQt6-WebEngine)...${NC}"
"${VENV_DIR}/bin/pip" install --upgrade pip
"${VENV_DIR}/bin/pip" install -r "${SCRIPT_DIR}/requirements.txt"
"${VENV_DIR}/bin/pip" install -e "${SCRIPT_DIR}"

# Install launcher script into ~/.local/bin/my3dcube
echo -e "${CYAN}[*] Installing launcher script into ${BIN_DIR}/my3dcube...${NC}"
cat << 'EOF' > "${BIN_DIR}/my3dcube"
#!/usr/bin/env bash
INSTALL_PREFIX="${HOME}/.local"
VENV_DIR="${INSTALL_PREFIX}/share/my3dcube/venv"

# Ensure GPU hardware acceleration is active
export QTWEBENGINE_CHROMIUM_FLAGS="--enable-gpu-rasterization --ignore-gpu-blocklist --autoplay-policy=no-user-gesture-required ${QTWEBENGINE_CHROMIUM_FLAGS}"

exec "${VENV_DIR}/bin/python3" -m my3dcube.main "$@"
EOF
chmod +x "${BIN_DIR}/my3dcube"

# Install Icons
echo -e "${CYAN}[*] Installing icons into FreeDesktop hicolor icon theme...${NC}"
cp -f "${SCRIPT_DIR}/assets/icons/my3dcube.svg" "${ICONS_DIR}/my3dcube.svg"

for SIZE in 16 32 48 64 128 256 512; do
    RASTER_DIR="${INSTALL_PREFIX}/share/icons/hicolor/${SIZE}x${SIZE}/apps"
    mkdir -p "${RASTER_DIR}"
    if [ -f "${SCRIPT_DIR}/assets/icons/my3dcube_${SIZE}x${SIZE}.png" ]; then
        cp -f "${SCRIPT_DIR}/assets/icons/my3dcube_${SIZE}x${SIZE}.png" "${RASTER_DIR}/my3dcube.png"
    fi
done

# Install Desktop Entry
echo -e "${CYAN}[*] Installing FreeDesktop application launcher...${NC}"
sed "s|my3dcube|${BIN_DIR}/my3dcube|g" "${SCRIPT_DIR}/my3dcube.desktop" > "${APPS_DIR}/my3dcube.desktop"
chmod +x "${APPS_DIR}/my3dcube.desktop"

# Install Systemd User Service (Optional)
SYSTEMD_USER_DIR="${HOME}/.config/systemd/user"
mkdir -p "${SYSTEMD_USER_DIR}"
cp -f "${SCRIPT_DIR}/my3dcube.service" "${SYSTEMD_USER_DIR}/my3dcube.service"

# Update Desktop & Icon Databases if tools available
command -v update-desktop-database &> /dev/null && update-desktop-database "${APPS_DIR}" 2>/dev/null || true
command -v gtk-update-icon-cache &> /dev/null && gtk-update-icon-cache -f -t "${INSTALL_PREFIX}/share/icons/hicolor" 2>/dev/null || true

echo ""
echo -e "${GREEN}====================================================${NC}"
echo -e "${GREEN}   Installation Complete! My-3D-Cube is ready.      ${NC}"
echo -e "${GREEN}====================================================${NC}"
echo ""
echo "You can launch the client in several ways:"
echo -e "  1. From your Application Menu (GNOME Dash, KDE Kickoff, etc.): Search for ${CYAN}My-3D-Cube${NC}"
echo -e "  2. From terminal: ${CYAN}my3dcube${NC} (Ensure ~/.local/bin is in your PATH)"
echo -e "  3. As a Desktop Wallpaper: ${CYAN}my3dcube --wallpaper${NC}"
echo -e "  4. As a Floating Widget:   ${CYAN}my3dcube --windowed${NC}"
echo -e "  5. As a Background Service: ${CYAN}systemctl --user enable --now my3dcube${NC}"
echo ""
