Add-Type -AssemblyName System.Drawing

function Create-Cube-Icon([int]$size, [string]$path) {
    $bmp = New-Object System.Drawing.Bitmap $size, $size
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.Clear([System.Drawing.Color]::Transparent)

    $pad = [float]$size * 0.12
    $midX = [float]$size / 2.0
    $midY = [float]$size / 2.0
    $radius = ([float]$size - (2.0 * $pad)) / 2.0

    $top = New-Object System.Drawing.PointF $midX, $pad
    $bottom = New-Object System.Drawing.PointF $midX, ([float]$size - $pad)
    $p1 = New-Object System.Drawing.PointF $pad, ($midY - ($radius * 0.5))
    $p2 = New-Object System.Drawing.PointF ([float]$size - $pad), ($midY - ($radius * 0.5))
    $p3 = New-Object System.Drawing.PointF $pad, ($midY + ($radius * 0.5))
    $p4 = New-Object System.Drawing.PointF ([float]$size - $pad), ($midY + ($radius * 0.5))
    $center = New-Object System.Drawing.PointF $midX, $midY

    # Draw Top Face
    $topBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush ($top, $center, [System.Drawing.Color]::FromArgb(56, 189, 248), [System.Drawing.Color]::FromArgb(14, 165, 233))
    $topPts = [System.Drawing.PointF[]]($top, $p2, $center, $p1)
    $g.FillPolygon($topBrush, $topPts)

    # Draw Left Face
    $leftBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush ($p1, $bottom, [System.Drawing.Color]::FromArgb(2, 132, 199), [System.Drawing.Color]::FromArgb(3, 105, 161))
    $leftPts = [System.Drawing.PointF[]]($p1, $center, $bottom, $p3)
    $g.FillPolygon($leftBrush, $leftPts)

    # Draw Right Face
    $rightBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush ($p2, $bottom, [System.Drawing.Color]::FromArgb(99, 102, 241), [System.Drawing.Color]::FromArgb(67, 56, 202))
    $rightPts = [System.Drawing.PointF[]]($center, $p2, $p4, $bottom)
    $g.FillPolygon($rightBrush, $rightPts)

    # Crisp outlines
    $penWidth = [Math]::Max(1.0, [float]$size / 32.0)
    $outlinePen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(200, 255, 255, 255)), $penWidth
    $g.DrawLine($outlinePen, $top, $center)
    $g.DrawLine($outlinePen, $center, $p1)
    $g.DrawLine($outlinePen, $center, $p2)
    $g.DrawLine($outlinePen, $center, $bottom)
    $outerPts = [System.Drawing.PointF[]]($top, $p2, $p4, $bottom, $p3, $p1)
    $g.DrawPolygon($outlinePen, $outerPts)

    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $outlinePen.Dispose()
    $topBrush.Dispose()
    $leftBrush.Dispose()
    $rightBrush.Dispose()
    $g.Dispose()
    $bmp.Dispose()
}

$iconDir = "f:\gallery_linux_August\assets\icons"
Create-Cube-Icon 16 "$iconDir\my3dcube_16x16.png"
Create-Cube-Icon 32 "$iconDir\my3dcube_32x32.png"
Create-Cube-Icon 48 "$iconDir\my3dcube_48x48.png"
Create-Cube-Icon 64 "$iconDir\my3dcube_64x64.png"
Create-Cube-Icon 128 "$iconDir\my3dcube_128x128.png"
Create-Cube-Icon 256 "$iconDir\my3dcube_256x256.png"
Create-Cube-Icon 512 "$iconDir\my3dcube_512x512.png"
Create-Cube-Icon 256 "$iconDir\my3dcube.png"

Write-Host "Generated 16x16, 32x32, 48x48, 64x64, 128x128, 256x256, 512x512 PNG icons successfully!"
