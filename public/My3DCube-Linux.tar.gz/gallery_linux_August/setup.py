from setuptools import setup, find_packages

setup(
    name="my3dcube",
    version="1.0.0",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "my3dcube": ["offline_player/*"],
    },
    install_requires=[
        "PyQt6>=6.5.0",
        "PyQt6-WebEngine>=6.5.0",
    ],
    entry_points={
        "console_scripts": [
            "my3dcube=my3dcube.main:main",
        ],
    },
)
