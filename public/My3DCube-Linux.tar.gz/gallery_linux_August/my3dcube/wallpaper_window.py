import os
import json
import logging
import asyncio
from pathlib import Path
from typing import Optional, Callable

logger = logging.getLogger("my3dcube.window")

# Import Qt bindings with graceful fallback between PyQt6 and PySide6
try:
    from PyQt6.QtCore import Qt, QUrl, pyqtSignal, QObject, QEventLoop, QTimer
    from PyQt6.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QApplication
    from PyQt6.QtGui import QIcon, QMouseEvent, QWheelEvent
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtWebEngineCore import QWebEngineSettings, QWebEngineProfile, QWebEnginePage
    QT_BINDING = "PyQt6"
except ImportError:
    try:
        from PySide6.QtCore import Qt, QUrl, Signal as pyqtSignal, QObject, QEventLoop, QTimer
        from PySide6.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QApplication
        from PySide6.QtGui import QIcon, QMouseEvent, QWheelEvent
        from PySide6.QtWebEngineWidgets import QWebEngineView
        from PySide6.QtWebEngineCore import QWebEngineSettings, QWebEngineProfile, QWebEnginePage
        QT_BINDING = "PySide6"
    except ImportError:
        QT_BINDING = None
        logger.warning("Neither PyQt6 nor PySide6 could be imported.")

from .desktop_hook import X11DesktopDocker, apply_desktop_window_hints, is_x11


class WebMessageBridge(QObject):
    """Bridge for receiving messages from JavaScript in QtWebEngine."""
    messageReceived = pyqtSignal(str)

    def onWebMessage(self, msg: str):
        self.messageReceived.emit(msg)


class WallpaperWindow(QMainWindow):
    """
    Main Wallpaper & Companion Window using QtWebEngine (Chromium).
    Renders Three.js 3D cube with hardware acceleration and provides two-way IPC.
    """

    def __init__(
        self,
        screen=None,
        monitor_index: int = 0,
        mode: str = "wallpaper",
        base_url: str = "http://162.35.101.183:5173",
        offline: bool = False,
        icon_path: Optional[str] = None
    ):
        super().__init__()
        self.target_screen = screen
        self.monitor_index = monitor_index
        self.current_mode = mode
        self.base_url = base_url.rstrip("/")
        self.offline = offline
        self.icon_path = icon_path

        self._docker = X11DesktopDocker() if is_x11() else None
        self._is_docked = False
        self._pending_answer: Optional[str] = None
        self._answer_loop: Optional[QEventLoop] = None

        # Mouse drag state
        self._is_dragging = False
        self._last_mouse_pos = None

        self._init_ui()
        self._load_content()

    def _init_ui(self):
        self.setWindowTitle(f"My-3D-Cube Wallpaper (Monitor {self.monitor_index + 1})")
        if self.icon_path and os.path.exists(self.icon_path):
            self.setWindowIcon(QIcon(self.icon_path))

        # Apply geometry
        if self.target_screen:
            geom = self.target_screen.geometry()
            self.setGeometry(geom)
        else:
            self.resize(1280, 800)

        # Presentation and Window hints
        apply_desktop_window_hints(self, self.current_mode)

        # Central WebEngine Widget
        self.central_widget = QWidget(self)
        self.layout = QVBoxLayout(self.central_widget)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.setCentralWidget(self.central_widget)

        self.web_view = QWebEngineView(self.central_widget)
        self.layout.addWidget(self.web_view)

        # Configure WebEngine Settings for WebGL and autoplay
        settings = self.web_view.settings()
        settings.setAttribute(QWebEngineSettings.WebAttribute.WebGLEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.Accelerated2dCanvasEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.PlaybackRequiresUserGesture, False)
        settings.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanAccessClipboard, True)

        # Transparent / Dark background
        self.setStyleSheet("background-color: #07090e;")

    def _load_content(self):
        if self.offline:
            player_path = Path(__file__).parent / "offline_player" / "index.html"
            url = QUrl.fromLocalFile(str(player_path.resolve()))
            logger.info(f"Loading offline 3D cube player: {url.toString()}")
        else:
            sep = "&" if "?" in self.base_url else "?"
            target_str = f"{self.base_url}{sep}wallpaper=true&monitorIndex={self.monitor_index}&minimal=true"
            url = QUrl(target_str)
            logger.info(f"Loading online 3D cube wallpaper: {target_str}")

        self.web_view.load(url)

    def showEvent(self, event):
        super().showEvent(event)
        if self.current_mode == "wallpaper" and is_x11() and not self._is_docked:
            win_id = int(self.winId())
            if self._docker:
                self._is_docked = self._docker.dock_window(win_id)

    def switch_mode(self, new_mode: str):
        self.current_mode = new_mode
        self.hide()
        apply_desktop_window_hints(self, new_mode)
        if self.target_screen:
            self.setGeometry(self.target_screen.geometry())
        self.show()
        if new_mode == "wallpaper" and is_x11() and self._docker:
            self._docker.dock_window(int(self.winId()))

    def post_message(self, action: str, **kwargs):
        payload = {"action": action}
        payload.update(kwargs)
        json_str = json.dumps(payload)
        script = f"window.postMessage({json_str}, '*');"
        self.run_js(script)

    def run_js(self, script: str, callback: Optional[Callable] = None):
        try:
            page = self.web_view.page()
            if page:
                if callback:
                    page.runJavaScript(script, callback)
                else:
                    page.runJavaScript(script)
        except Exception as e:
            logger.debug(f"run_js error: {e}")

    # Control Helpers
    def refresh_media(self):
        self.post_message("refresh")

    def set_speed(self, speed: float):
        self.post_message("setSpeed", speed=float(speed))

    def toggle_spin(self, spin: Optional[bool] = None):
        if spin is not None:
            self.post_message("toggleSpin", spin=spin)
        else:
            self.post_message("toggleSpin")

    def set_weather(self, weather: str):
        self.post_message("setWeather", weather=weather.lower())

    def set_audio_mode(self, mode: str):
        self.post_message("setAudioMode", mode=mode.lower())

    def send_system_audio(self, bands: list, bass: float, mid: float, treble: float):
        self.post_message("systemAudio", bands=bands, bass=bass, mid=mid, treble=treble)

    def send_audio_beat(self, volume: float):
        self.post_message("audioBeat", volume=volume)

    def send_drag_rotate(self, delta_x: int, delta_y: int):
        self.post_message("dragRotate", deltaX=delta_x, deltaY=delta_y)

    # WebRTC Chrome Extension Casting Helpers
    def send_stream_offer(self, face_index: int, sdp: str, timeout_ms: int = 4000) -> Optional[str]:
        """
        Injects WebRTC offer into WallpaperView and awaits answer SDP.
        """
        self._pending_answer = None
        self._answer_loop = QEventLoop()

        # JS snippet that invokes handleWebRtcOffer
        offer_payload = json.dumps({"action": "webrtc-offer", "faceIndex": face_index, "sdp": sdp})
        self.run_js(f"window.postMessage({offer_payload}, '*');")

        # Query page for answer or listen for callback
        def check_answer():
            query_js = "window.__lastWebRtcAnswer || (window.livePeerConnectionRef && window.livePeerConnectionRef.localDescription ? window.livePeerConnectionRef.localDescription.sdp : null);"
            self.run_js(query_js, on_query_result)

        def on_query_result(res):
            if res and isinstance(res, str) and len(res) > 20:
                self._pending_answer = res
                if self._answer_loop and self._answer_loop.isRunning():
                    self._answer_loop.quit()

        timer = QTimer()
        timer.setInterval(250)
        timer.timeout.connect(check_answer)
        timer.start()

        timeout_timer = QTimer()
        timeout_timer.setSingleShot(True)
        timeout_timer.timeout.connect(lambda: self._answer_loop.quit() if self._answer_loop and self._answer_loop.isRunning() else None)
        timeout_timer.start(timeout_ms)

        self._answer_loop.exec()
        timer.stop()
        timeout_timer.stop()

        return self._pending_answer

    def send_ice_candidate(self, face_index: int, candidate: dict):
        self.post_message("webrtc-candidate", faceIndex=face_index, candidate=candidate)

    def send_stop_stream(self, face_index: int):
        self.post_message("webrtc-stop", faceIndex=face_index)

    # Mouse Events for direct desktop drag interaction
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self._is_dragging = True
            self._last_mouse_pos = event.position().toPoint()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent):
        if self._is_dragging and self._last_mouse_pos:
            curr_pos = event.position().toPoint()
            delta_x = curr_pos.x() - self._last_mouse_pos.x()
            delta_y = curr_pos.y() - self._last_mouse_pos.y()
            self.send_drag_rotate(delta_x, delta_y)
            self._last_mouse_pos = curr_pos
        else:
            # Mouse parallax
            pos = event.position().toPoint()
            self.post_message("mouseMove", clientX=pos.x(), clientY=pos.y())
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self._is_dragging = False
            self._last_mouse_pos = None
        super().mouseReleaseEvent(event)

    def closeEvent(self, event):
        if self._docker:
            self._docker.close()
        super().closeEvent(event)
