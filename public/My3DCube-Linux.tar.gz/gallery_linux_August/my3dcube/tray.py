import os
import logging
import webbrowser
from typing import Optional

logger = logging.getLogger("my3dcube.tray")

try:
    from PyQt6.QtWidgets import QSystemTrayIcon, QMenu, QMessageBox
    from PyQt6.QtGui import QIcon, QAction, QActionGroup
except ImportError:
    try:
        from PySide6.QtWidgets import QSystemTrayIcon, QMenu, QMessageBox
        from PySide6.QtGui import QIcon, QAction, QActionGroup
    except ImportError:
        pass

from .autostart import is_autostart_enabled, set_autostart


class LinuxSystemTray(QSystemTrayIcon):
    """
    Linux System Tray Controller & AppIndicator for My-3D-Cube.
    Compatible with GNOME, KDE Plasma, XFCE, Cinnamon, and FreeDesktop status notifiers.
    """

    def __init__(self, app_controller, icon_path: Optional[str] = None):
        super().__init__()
        self.app = app_controller
        self.icon_path = icon_path

        if self.icon_path and os.path.exists(self.icon_path):
            self.setIcon(QIcon(self.icon_path))
        self.setToolTip("My-3D-Cube: Linux Live Desktop Wallpaper")

        self._build_menu()

    def _build_menu(self):
        self.menu = QMenu()

        # 1. Title / Header (Disabled action)
        title_action = QAction("🧊 My-3D-Cube Live Wallpaper", self.menu)
        title_action.setEnabled(False)
        self.menu.addAction(title_action)
        self.menu.addSeparator()

        # 2. Primary Actions
        sync_action = QAction("🔄 Refresh Cube Media", self.menu)
        sync_action.triggered.connect(self.app.refresh_all_media)
        self.menu.addAction(sync_action)

        web_action = QAction("🌐 Open Web Gallery", self.menu)
        web_action.triggered.connect(self._open_web_gallery)
        self.menu.addAction(web_action)

        self.menu.addSeparator()

        # 3. Rotation & Speed Controls
        self.pause_action = QAction("⏸️ Pause Rotation", self.menu)
        self.pause_action.triggered.connect(self._toggle_rotation)
        self.menu.addAction(self.pause_action)

        speed_menu = self.menu.addMenu("⚡ Rotation Speed")
        speed_group = QActionGroup(self)
        speed_group.setExclusive(True)

        current_speed = self.app.config.get("speed", 0.8)
        for label, spd in [("Slow (0.4x)", 0.4), ("Normal (0.8x)", 0.8), ("Fast (1.6x)", 1.6)]:
            act = QAction(label, speed_menu, checkable=True)
            if abs(current_speed - spd) < 0.05:
                act.setChecked(True)
            act.triggered.connect(lambda checked, s=spd: self.app.set_speed(s))
            speed_group.addAction(act)
            speed_menu.addAction(act)

        # 4. Weather Effects Submenu
        weather_menu = self.menu.addMenu("🌤️ Weather System")
        weather_group = QActionGroup(self)
        weather_group.setExclusive(True)

        current_weather = self.app.config.get("weather", "auto")
        weather_options = [
            ("Live Auto Weather", "auto"),
            ("Clear Sky", "clear"),
            ("Gentle Rain", "rain"),
            ("Snow Flurries", "snow"),
            ("Cloudy", "clouds"),
            ("Thunderstorm", "storm")
        ]
        for label, code in weather_options:
            act = QAction(label, weather_menu, checkable=True)
            if current_weather == code:
                act.setChecked(True)
            act.triggered.connect(lambda checked, c=code: self.app.set_weather(c))
            weather_group.addAction(act)
            weather_menu.addAction(act)

        # 5. Audio Visualizer Submenu
        audio_menu = self.menu.addMenu("🎵 Audio Visualizer")
        audio_group = QActionGroup(self)
        audio_group.setExclusive(True)

        current_audio = self.app.config.get("audio_mode", "off")
        audio_options = [
            ("Disabled", "off"),
            ("Desktop Audio (PulseAudio / PipeWire Loopback)", "system"),
            ("Synthesized Beat Pulse", "beat"),
            ("Microphone Input", "mic")
        ]
        for label, mode in audio_options:
            act = QAction(label, audio_menu, checkable=True)
            if current_audio == mode:
                act.setChecked(True)
            act.triggered.connect(lambda checked, m=mode: self.app.set_audio_mode(m))
            audio_group.addAction(act)
            audio_menu.addAction(act)

        # 6. Window / Display Modes
        mode_menu = self.menu.addMenu("🪟 Window Mode")
        mode_group = QActionGroup(self)
        mode_group.setExclusive(True)

        current_mode = self.app.config.get("mode", "wallpaper")
        for label, m in [("Desktop Wallpaper", "wallpaper"), ("Floating Companion Widget", "windowed"), ("Fullscreen", "fullscreen")]:
            act = QAction(label, mode_menu, checkable=True)
            if current_mode == m:
                act.setChecked(True)
            act.triggered.connect(lambda checked, new_m=m: self.app.set_window_mode(new_m))
            mode_group.addAction(act)
            mode_menu.addAction(act)

        self.menu.addSeparator()

        # 7. Autostart checkbox
        self.autostart_action = QAction("🚀 Start with Linux", self.menu, checkable=True)
        self.autostart_action.setChecked(is_autostart_enabled())
        self.autostart_action.triggered.connect(self._toggle_autostart)
        self.menu.addAction(self.autostart_action)

        # 8. About & Settings
        about_action = QAction("ℹ️ About My-3D-Cube", self.menu)
        about_action.triggered.connect(self._show_about)
        self.menu.addAction(about_action)

        self.menu.addSeparator()

        # 9. Quit
        quit_action = QAction("❌ Quit Wallpaper", self.menu)
        quit_action.triggered.connect(self.app.quit)
        self.menu.addAction(quit_action)

        self.setContextMenu(self.menu)

    def _open_web_gallery(self):
        url = self.app.config.get("server_url", "http://162.35.101.183:5173")
        webbrowser.open(url)

    def _toggle_rotation(self):
        is_spinning = not self.app.config.get("is_spinning", True)
        self.app.set_spinning(is_spinning)
        self.pause_action.setText("▶️ Resume Rotation" if not is_spinning else "⏸️ Pause Rotation")

    def _toggle_autostart(self, checked: bool):
        set_autostart(checked)
        self.app.config.set("autostart", checked)

    def _show_about(self):
        QMessageBox.about(
            None,
            "About My-3D-Cube Linux Client",
            "<h3>My-3D-Cube: Linux Live Wallpaper & Companion</h3>"
            "<p>Version: <b>1.0.0</b></p>"
            "<p>A dynamic 3D spinning cube live desktop wallpaper for Linux, powered by Python, QtWebEngine (Chromium), and Three.js.</p>"
            "<p><b>Server URL:</b> " + self.app.config.get("server_url", "") + "</p>"
            "<p><b>Controls:</b> Left-Click and Drag on the desktop to rotate the 3D cube.</p>"
            "<p>© 2026 bonz. Distributed under MIT License.</p>"
        )
