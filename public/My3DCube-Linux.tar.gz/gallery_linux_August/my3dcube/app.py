import os
import sys
import json
import signal
import socket
import logging
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger("my3dcube.app")

try:
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtCore import QTimer
except ImportError:
    try:
        from PySide6.QtWidgets import QApplication
        from PySide6.QtCore import QTimer
    except ImportError:
        pass

from .config import ConfigManager
from .wallpaper_window import WallpaperWindow
from .tray import LinuxSystemTray
from .audio_capture import LinuxAudioCapture
from .stream_bridge import LocalStreamBridge

LOCK_SOCKET_PATH = "/tmp/my3dcube.sock"


class ApplicationController:
    """
    Central controller managing lifecycle, multi-monitor windows, system tray,
    audio capture, and WebRTC streaming bridge.
    """

    def __init__(self, cli_args=None):
        self.cli_args = cli_args
        self.config = ConfigManager()
        self.windows: List[WallpaperWindow] = []
        self.tray: Optional[LinuxSystemTray] = None
        self.audio_capture: Optional[LinuxAudioCapture] = None
        self.stream_bridge: Optional[LocalStreamBridge] = None
        self.qt_app: Optional[QApplication] = None
        self._single_instance_sock = None

        # Apply CLI overrides to config
        if cli_args:
            if getattr(cli_args, "url", None):
                self.config.set("server_url", cli_args.url)
            if getattr(cli_args, "mode", None):
                self.config.set("mode", cli_args.mode)
            if getattr(cli_args, "speed", None) is not None:
                self.config.set("speed", cli_args.speed)
            if getattr(cli_args, "weather", None):
                self.config.set("weather", cli_args.weather)
            if getattr(cli_args, "audio_mode", None):
                self.config.set("audio_mode", cli_args.audio_mode)
            if getattr(cli_args, "offline", False):
                self.config.set("offline_mode", True)
            if getattr(cli_args, "monitor", None) is not None:
                self.config.set("monitor_index", cli_args.monitor)

    def ensure_single_instance(self) -> bool:
        """
        Ensures only one instance of My-3D-Cube runs at a time.
        """
        self._single_instance_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            self._single_instance_sock.bind(LOCK_SOCKET_PATH)
            self._single_instance_sock.listen(1)
            logger.info(f"Single instance lock acquired at {LOCK_SOCKET_PATH}")
            return True
        except socket.error:
            logger.warning("Another instance of My-3D-Cube is already running. Notifying existing instance...")
            try:
                client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                client.connect(LOCK_SOCKET_PATH)
                client.sendall(b"WAKEUP\n")
                client.close()
            except Exception:
                pass
            return False

    def run(self) -> int:
        if not self.ensure_single_instance():
            print("My-3D-Cube is already running.")
            return 0

        # Enable hardware acceleration flags before QApplication creation
        os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (
            "--enable-gpu-rasterization "
            "--ignore-gpu-blocklist "
            "--enable-zero-copy "
            "--autoplay-policy=no-user-gesture-required"
        )

        self.qt_app = QApplication.instance() or QApplication(sys.argv)
        self.qt_app.setApplicationName("My3DCube")
        self.qt_app.setOrganizationName("bonz")
        self.qt_app.setQuitOnLastWindowClosed(False)

        # Locate icon
        icon_path = str((Path(__file__).parent.parent / "assets" / "icons" / "my3dcube.svg").resolve())

        # 1. Initialize Windows across connected monitors
        screens = self.qt_app.screens()
        target_mon = self.config.get("monitor_index", -1)
        mode = self.config.get("mode", "wallpaper")
        base_url = self.config.get("server_url", "http://162.35.101.183:5173")
        offline = self.config.get("offline_mode", False)

        logger.info(f"Detected {len(screens)} screen(s). Spawning wallpaper window(s)...")

        if target_mon >= 0 and target_mon < len(screens):
            # Single monitor mode
            win = WallpaperWindow(
                screen=screens[target_mon],
                monitor_index=target_mon,
                mode=mode,
                base_url=base_url,
                offline=offline,
                icon_path=icon_path
            )
            self.windows.append(win)
            win.show()
        else:
            # Multi-monitor mode: spawn for every screen
            for idx, scr in enumerate(screens):
                win = WallpaperWindow(
                    screen=scr,
                    monitor_index=idx,
                    mode=mode,
                    base_url=base_url,
                    offline=offline,
                    icon_path=icon_path
                )
                self.windows.append(win)
                win.show()

        # 2. Initialize System Tray
        self.tray = LinuxSystemTray(self, icon_path=icon_path)
        self.tray.show()

        # 3. Initialize Audio Capture
        self.audio_capture = LinuxAudioCapture(callback=self._on_audio_data)
        if self.config.get("audio_mode") == "system":
            self.audio_capture.start()

        # 4. Initialize LocalStreamBridge
        self._init_stream_bridge()

        # 5. Handle Unix signals
        signal.signal(signal.SIGINT, lambda sig, frame: self.quit())
        signal.signal(signal.SIGTERM, lambda sig, frame: self.quit())

        # Let Python process signals periodically
        sig_timer = QTimer()
        sig_timer.start(500)
        sig_timer.timeout.connect(lambda: None)

        logger.info("My-3D-Cube Linux Client running.")
        ret = self.qt_app.exec()
        self._cleanup()
        return ret

    def _init_stream_bridge(self):
        bridge_port = self.config.get("bridge_port", 48124)
        self.stream_bridge = LocalStreamBridge(port=bridge_port)

        self.stream_bridge.get_monitors_handler = self._get_monitors_list
        self.stream_bridge.offer_handler = self._handle_stream_offer
        self.stream_bridge.candidate_handler = self._handle_stream_candidate
        self.stream_bridge.stop_handler = self._handle_stream_stop

        self.stream_bridge.start()

    def _get_monitors_list(self) -> list:
        result = []
        for win in self.windows:
            scr = win.target_screen
            geom = scr.geometry() if scr else None
            result.append({
                "index": win.monitor_index,
                "name": f"Monitor {win.monitor_index + 1} ({geom.width()}x{geom.height()})" if geom else f"Monitor {win.monitor_index + 1}",
                "deviceName": scr.name() if scr else "Default",
                "isPrimary": scr == QApplication.primaryScreen() if scr else True
            })
        return result

    def _handle_stream_offer(self, face_index: int, monitor_index: int, sdp: str) -> Optional[str]:
        target_win = None
        if monitor_index >= 0:
            for w in self.windows:
                if w.monitor_index == monitor_index:
                    target_win = w
                    break

        if not target_win and self.windows:
            target_win = self.windows[0]

        if target_win:
            return target_win.send_stream_offer(face_index, sdp)
        return None

    def _handle_stream_candidate(self, face_index: int, monitor_index: int, candidate: dict):
        if monitor_index >= 0:
            for w in self.windows:
                if w.monitor_index == monitor_index:
                    w.send_ice_candidate(face_index, candidate)
                    return
        for w in self.windows:
            w.send_ice_candidate(face_index, candidate)

    def _handle_stream_stop(self, face_index: int, monitor_index: int):
        if monitor_index >= 0:
            for w in self.windows:
                if w.monitor_index == monitor_index:
                    w.send_stop_stream(face_index)
                    return
        for w in self.windows:
            w.send_stop_stream(face_index)

    def _on_audio_data(self, bands: list, bass: float, mid: float, treble: float, is_beat: bool):
        for win in self.windows:
            win.send_system_audio(bands, bass, mid, treble)
            if is_beat:
                win.send_audio_beat(bass)

    # Controller Actions
    def refresh_all_media(self):
        for win in self.windows:
            win.refresh_media()

    def set_speed(self, speed: float):
        self.config.set("speed", speed)
        for win in self.windows:
            win.set_speed(speed)

    def set_spinning(self, is_spinning: bool):
        self.config.set("is_spinning", is_spinning)
        for win in self.windows:
            win.toggle_spin(is_spinning)

    def set_weather(self, weather: str):
        self.config.set("weather", weather)
        for win in self.windows:
            win.set_weather(weather)

    def set_audio_mode(self, mode: str):
        self.config.set("audio_mode", mode)
        if mode == "system":
            if self.audio_capture:
                self.audio_capture.start()
        else:
            if self.audio_capture:
                self.audio_capture.stop()

        for win in self.windows:
            win.set_audio_mode(mode)

    def set_window_mode(self, mode: str):
        self.config.set("mode", mode)
        for win in self.windows:
            win.switch_mode(mode)

    def quit(self):
        logger.info("Quitting My-3D-Cube...")
        self._cleanup()
        if self.qt_app:
            self.qt_app.quit()

    def _cleanup(self):
        if self.audio_capture:
            self.audio_capture.stop()
        if self.stream_bridge:
            self.stream_bridge.stop()
        if self._single_instance_sock:
            try:
                self._single_instance_sock.close()
                if os.path.exists(LOCK_SOCKET_PATH):
                    os.unlink(LOCK_SOCKET_PATH)
            except Exception:
                pass
