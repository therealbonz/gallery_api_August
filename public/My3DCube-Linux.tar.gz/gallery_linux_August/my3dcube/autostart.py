import os
import sys
import logging
from pathlib import Path

logger = logging.getLogger("my3dcube.autostart")

DESKTOP_ENTRY_TEMPLATE = """[Desktop Entry]
Type=Application
Name=My-3D-Cube Live Wallpaper
Comment=3D Spinning Cube Live Desktop Wallpaper & Companion
Exec={exec_cmd}
Icon=my3dcube
Terminal=false
Categories=Utility;Graphics;Screensaver;
StartupNotify=false
X-GNOME-Autostart-enabled=true
X-KDE-autostart-after=panel
"""


def get_autostart_dir() -> Path:
    xdg_config = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config:
        base = Path(xdg_config)
    else:
        base = Path.home() / ".config"
    autostart_dir = base / "autostart"
    autostart_dir.mkdir(parents=True, exist_ok=True)
    return autostart_dir


def get_autostart_file() -> Path:
    return get_autostart_dir() / "my3dcube.desktop"


def is_autostart_enabled() -> bool:
    return get_autostart_file().exists()


def set_autostart(enabled: bool, custom_exec: str = None) -> bool:
    target = get_autostart_file()
    try:
        if enabled:
            if custom_exec:
                exec_cmd = custom_exec
            elif getattr(sys, "frozen", False):
                exec_cmd = f"{sys.executable} --wallpaper"
            else:
                exec_cmd = f"my3dcube --wallpaper"

            content = DESKTOP_ENTRY_TEMPLATE.format(exec_cmd=exec_cmd)
            with open(target, "w", encoding="utf-8") as f:
                f.write(content)
            target.chmod(0o755)
            logger.info(f"Enabled Linux autostart: {target}")
            return True
        else:
            if target.exists():
                target.unlink()
                logger.info(f"Disabled Linux autostart (removed {target})")
            return True
    except Exception as e:
        logger.error(f"Failed to update autostart setting: {e}")
        return False
