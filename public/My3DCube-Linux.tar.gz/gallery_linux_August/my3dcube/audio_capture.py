import math
import shutil
import struct
import logging
import threading
import subprocess
from typing import Callable, Optional

logger = logging.getLogger("my3dcube.audio_capture")


class LinuxAudioCapture:
    """
    Captures system desktop audio output loopback (Spotify, YouTube, games, etc.)
    using PulseAudio / PipeWire's default monitor source.
    Computes real-time RMS, frequency bands (bass, mid, treble), and beat pulses.
    """

    def __init__(self, callback: Optional[Callable[[list, float, float, float, bool], None]] = None):
        self.callback = callback
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._process: Optional[subprocess.Popen] = None
        self._rate = 44100
        self._channels = 1
        self._chunk_size = 1024  # samples per chunk (approx 23ms at 44.1kHz)

        # Running energy baseline for beat detection
        self._bass_history = []
        self._history_len = 20

    def start(self):
        if self._running:
            return

        # Check for parec or pacat
        parec_path = shutil.which("parec") or shutil.which("pacat")
        if not parec_path:
            logger.info("parec/pacat not found in PATH; attempting sounddevice fallback if available.")
            self._try_sounddevice()
            return

        self._running = True
        self._thread = threading.Thread(target=self._capture_parec_loop, args=(parec_path,), daemon=True)
        self._thread.start()
        logger.info(f"Started system audio loopback capture via {parec_path}")

    def _try_sounddevice(self):
        try:
            import sounddevice as sd
            import numpy as np

            self._running = True

            def sd_callback(indata, frames, time_info, status):
                if not self._running:
                    return
                samples = indata[:, 0]
                self._process_float_samples(samples)

            def run_sd():
                try:
                    with sd.InputStream(channels=1, samplerate=self._rate, callback=sd_callback, blocksize=self._chunk_size):
                        while self._running:
                            threading.Event().wait(0.5)
                except Exception as e:
                    logger.warning(f"sounddevice capture error: {e}")

            self._thread = threading.Thread(target=run_sd, daemon=True)
            self._thread.start()
            logger.info("Started audio capture via sounddevice fallback.")
        except ImportError:
            logger.warning("Neither parec nor sounddevice is available. Audio visualizer will use simulated beat mode.")

    def stop(self):
        self._running = False
        if self._process:
            try:
                self._process.terminate()
                self._process.wait(timeout=1.0)
            except Exception:
                try:
                    self._process.kill()
                except Exception:
                    pass
            self._process = None

        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)
        self._thread = None
        logger.info("Stopped audio capture.")

    def _capture_parec_loop(self, parec_cmd: str):
        # Read raw 16-bit little-endian signed mono PCM from @DEFAULT_MONITOR@
        cmd = [
            parec_cmd,
            "--format=s16le",
            f"--rate={self._rate}",
            f"--channels={self._channels}",
            "--device=@DEFAULT_MONITOR@",
            "--raw"
        ]

        try:
            self._process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                bufsize=self._chunk_size * 2 * 4
            )

            bytes_per_sample = 2
            bytes_to_read = self._chunk_size * bytes_per_sample

            while self._running and self._process.poll() is None:
                raw_data = self._process.stdout.read(bytes_to_read)
                if not raw_data or len(raw_data) < bytes_to_read:
                    break

                # Unpack 16-bit integers
                count = len(raw_data) // 2
                samples = struct.unpack(f"<{count}h", raw_data)
                # Normalize to float [-1.0, 1.0]
                float_samples = [s / 32768.0 for s in samples]
                self._process_float_samples(float_samples)

        except Exception as e:
            if self._running:
                logger.warning(f"parec audio loop error: {e}")
        finally:
            if self._process:
                try:
                    self._process.terminate()
                except Exception:
                    pass
                self._process = None

    def _process_float_samples(self, samples):
        n = len(samples)
        if n == 0:
            return

        # 1. Calculate overall RMS energy
        sum_sq = sum(s * s for s in samples)
        rms = math.sqrt(sum_sq / n)

        # 2. Simple frequency approximation (Zero-crossing rate and 3-band decomposition)
        # Split chunk into 16 discrete equalizer bands for visualizer ring
        num_bands = 16
        band_step = n // num_bands
        bands = []
        for b in range(num_bands):
            sub = samples[b * band_step:(b + 1) * band_step]
            if sub:
                band_rms = math.sqrt(sum(x * x for x in sub) / len(sub))
                # Boost and clamp to [0.0, 1.0]
                val = min(1.0, band_rms * 3.5)
                bands.append(round(val, 3))
            else:
                bands.append(0.0)

        # 3. Bass (first 4 bands), Mid (next 6 bands), Treble (last 6 bands)
        bass = min(1.0, sum(bands[0:4]) / 4.0 * 1.5)
        mid = min(1.0, sum(bands[4:10]) / 6.0 * 1.8)
        treble = min(1.0, sum(bands[10:16]) / 6.0 * 2.2)

        # 4. Beat detection: compare bass to running moving average
        self._bass_history.append(bass)
        if len(self._bass_history) > self._history_len:
            self._bass_history.pop(0)

        avg_bass = sum(self._bass_history) / len(self._bass_history)
        is_beat = bass > (avg_bass * 1.45) and bass > 0.25

        if self.callback:
            try:
                self.callback(bands, round(bass, 3), round(mid, 3), round(treble, 3), is_beat)
            except Exception:
                pass
