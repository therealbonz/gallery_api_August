#!/usr/bin/env python3
import sys
import argparse
import logging
from . import __version__


def setup_logging(verbose: bool = False):
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S"
    )


def main():
    parser = argparse.ArgumentParser(
        prog="my3dcube",
        description="My-3D-Cube: Linux Live Desktop Wallpaper & Companion"
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"My-3D-Cube Linux Client v{__version__}"
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose debug logging"
    )

    # Window Mode
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument(
        "--wallpaper",
        action="store_const",
        dest="mode",
        const="wallpaper",
        help="Run as desktop live wallpaper behind desktop icons (default)"
    )
    mode_group.add_argument(
        "--windowed",
        action="store_const",
        dest="mode",
        const="windowed",
        help="Run as an interactive floating companion desktop widget"
    )
    mode_group.add_argument(
        "--fullscreen",
        action="store_const",
        dest="mode",
        const="fullscreen",
        help="Run in borderless fullscreen screensaver mode"
    )

    # Display / Monitor
    parser.add_argument(
        "-m", "--monitor",
        type=int,
        default=None,
        help="Target monitor index (0 for primary display)"
    )
    parser.add_argument(
        "--all-monitors",
        action="store_const",
        dest="monitor",
        const=-1,
        help="Spawn wallpaper instances across all detected monitors"
    )

    # Connection & Media Settings
    parser.add_argument(
        "--url",
        type=str,
        default=None,
        help="Custom My-3D-Cube server URL (default: http://162.35.101.183:5173)"
    )
    parser.add_argument(
        "--speed",
        type=float,
        default=None,
        choices=[0.4, 0.8, 1.6],
        help="Cube rotation speed: 0.4 (slow), 0.8 (normal), 1.6 (fast)"
    )
    parser.add_argument(
        "--weather",
        type=str,
        default=None,
        choices=["auto", "clear", "rain", "snow", "clouds", "storm"],
        help="Active weather overlay effect"
    )
    parser.add_argument(
        "--audio-mode",
        type=str,
        default=None,
        choices=["off", "system", "beat", "mic"],
        help="Audio visualizer mode (system = PulseAudio/PipeWire loopback)"
    )
    parser.add_argument(
        "--offline",
        action="store_true",
        help="Force bundled offline WebGL player"
    )
    parser.add_argument(
        "--headless-bridge",
        action="store_true",
        help="Run only the LocalStreamBridge HTTP server on port 48124 without GUI"
    )

    args = parser.parse_args()
    setup_logging(args.verbose)

    if args.headless_bridge:
        from .stream_bridge import LocalStreamBridge
        import time
        bridge = LocalStreamBridge()
        bridge.start()
        print("LocalStreamBridge running in headless mode on port 48124. Press Ctrl+C to exit.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            bridge.stop()
        return 0

    from .app import ApplicationController
    app = ApplicationController(cli_args=args)
    return app.run()


if __name__ == "__main__":
    sys.exit(main())
