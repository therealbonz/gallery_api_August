import os
import json
import logging
from pathlib import Path

logger = logging.getLogger("my3dcube.config")

DEFAULT_CONFIG = {
    "server_url": "http://162.35.101.183:5173",
    "api_url": "http://162.35.101.183:3000",
    "mode": "wallpaper",  # 'wallpaper', 'windowed', 'fullscreen'
    "speed": 0.8,         # 0.4 (slow), 0.8 (normal), 1.6 (fast)
    "is_spinning": True,
    "weather": "auto",    # 'auto', 'clear', 'rain', 'snow', 'clouds', 'storm'
    "audio_mode": "off",  # 'off', 'system', 'beat', 'mic'
    "monitor_index": -1,  # -1 = all monitors, 0 = primary, 1, 2, ...
    "autostart": False,
    "offline_mode": False,
    "window_width": 1024,
    "window_height": 768,
    "bridge_port": 48124,
    "hardware_acceleration": True,
}


def get_config_dir() -> Path:
    xdg_config = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config:
        base = Path(xdg_config)
    else:
        base = Path.home() / ".config"
    config_dir = base / "my3dcube"
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


def get_config_path() -> Path:
    return get_config_dir() / "config.json"


class ConfigManager:
    def __init__(self):
        self.config_path = get_config_path()
        self.data = dict(DEFAULT_CONFIG)
        self.load()

    def load(self):
        if self.config_path.exists():
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    user_data = json.load(f)
                    self.data.update(user_data)
                logger.info(f"Loaded configuration from {self.config_path}")
            except Exception as e:
                logger.warning(f"Failed to load config: {e}. Using defaults.")
        else:
            self.save()

    def save(self):
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2)
            logger.debug(f"Saved configuration to {self.config_path}")
        except Exception as e:
            logger.error(f"Failed to save configuration: {e}")

    def get(self, key: str, default=None):
        return self.data.get(key, default if default is not None else DEFAULT_CONFIG.get(key))

    def set(self, key: str, value):
        self.data[key] = value
        self.save()

    def update(self, **kwargs):
        self.data.update(kwargs)
        self.save()
