import json
import logging
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from typing import Callable, Optional, Any, Dict

logger = logging.getLogger("my3dcube.stream_bridge")


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class BridgeRequestHandler(BaseHTTPRequestHandler):
    # Quiet standard logging
    def log_message(self, format, *args):
        logger.debug("%s - - [%s] %s" % (self.client_address[0], self.log_date_time_string(), format % args))

    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")

    def do_OPTIONS(self):
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()

    def _send_json(self, status_code: int, data: Any):
        payload = json.dumps(data).encode("utf-8")
        self.send_response(status_code)
        self._send_cors_headers()
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        path = self.path.split("?")[0].rstrip("/").lower()

        if path == "" or path == "/api/status":
            self._send_json(200, {
                "status": "ok",
                "bridge": "My3DCube Linux LocalStreamBridge",
                "version": "1.0.0",
                "active": True
            })
            return

        if path == "/api/monitors":
            monitors = []
            if self.server.bridge and self.server.bridge.get_monitors_handler:
                try:
                    monitors = self.server.bridge.get_monitors_handler()
                except Exception as e:
                    logger.warning(f"get_monitors_handler error: {e}")
            self._send_json(200, {"monitors": monitors})
            return

        self._send_json(404, {"error": f"Endpoint not found: {self.path}"})

    def do_POST(self):
        path = self.path.split("?")[0].rstrip("/").lower()
        content_len = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_len).decode("utf-8") if content_len > 0 else "{}"

        try:
            doc = json.loads(body) if body else {}
        except Exception:
            doc = {}

        if path == "/api/stream/offer":
            face_idx = doc.get("faceIndex", -1)
            monitor_idx = doc.get("monitorIndex", -1)
            sdp = doc.get("sdp", "")

            logger.info(f"LocalStreamBridge received WebRTC Offer for face {face_idx}, monitor {monitor_idx}")

            answer_sdp = None
            if self.server.bridge and self.server.bridge.offer_handler:
                try:
                    answer_sdp = self.server.bridge.offer_handler(face_idx, monitor_idx, sdp)
                except Exception as e:
                    logger.error(f"offer_handler failed: {e}")

            if answer_sdp:
                self._send_json(200, {
                    "type": "answer",
                    "sdp": answer_sdp,
                    "faceIndex": face_idx,
                    "monitorIndex": monitor_idx
                })
            else:
                self._send_json(504, {
                    "error": "Timed out waiting for 3D Cube wallpaper to generate WebRTC answer."
                })
            return

        if path == "/api/stream/candidate":
            face_idx = doc.get("faceIndex", -1)
            monitor_idx = doc.get("monitorIndex", -1)
            candidate = doc.get("candidate", {})

            if self.server.bridge and self.server.bridge.candidate_handler:
                try:
                    self.server.bridge.candidate_handler(face_idx, monitor_idx, candidate)
                except Exception as e:
                    logger.warning(f"candidate_handler error: {e}")

            self._send_json(200, {"status": "ok"})
            return

        if path == "/api/stream/stop":
            face_idx = doc.get("faceIndex", -1)
            monitor_idx = doc.get("monitorIndex", -1)

            if self.server.bridge and self.server.bridge.stop_handler:
                try:
                    self.server.bridge.stop_handler(face_idx, monitor_idx)
                except Exception as e:
                    logger.warning(f"stop_handler error: {e}")

            self._send_json(200, {"status": "stopped"})
            return

        self._send_json(404, {"error": f"Endpoint not found: {self.path}"})


class LocalStreamBridge:
    """
    Local HTTP & WebRTC signaling bridge server running on port 48124.
    Enables the My-3D-Cube Chrome Extension to cast browser tabs / YouTube directly
    onto 3D cube faces on Linux.
    """

    PORT = 48124

    def __init__(self, port: int = PORT):
        self.port = port
        self.server: Optional[ThreadedHTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._is_running = False

        self.offer_handler: Optional[Callable[[int, int, str], Optional[str]]] = None
        self.candidate_handler: Optional[Callable[[int, int, Any], None]] = None
        self.stop_handler: Optional[Callable[[int, int], None]] = None
        self.get_monitors_handler: Optional[Callable[[], list]] = None

    @property
    def is_running(self) -> bool:
        return self._is_running

    def start(self) -> bool:
        if self._is_running:
            return True

        try:
            self.server = ThreadedHTTPServer(("127.0.0.1", self.port), BridgeRequestHandler)
            self.server.bridge = self
            self._is_running = True
            self._thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self._thread.start()
            logger.info(f"LocalStreamBridge active on http://127.0.0.1:{self.port}/")
            return True
        except Exception as e:
            logger.error(f"Failed to start LocalStreamBridge on port {self.port}: {e}")
            self._is_running = False
            return False

    def stop(self):
        if not self._is_running:
            return
        self._is_running = False
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception:
                pass
            self.server = None
        logger.info("LocalStreamBridge stopped.")
