import os
import sys
import ctypes
import logging
from typing import Optional

logger = logging.getLogger("my3dcube.desktop_hook")


def is_wayland() -> bool:
    return os.environ.get("XDG_SESSION_TYPE", "").lower() == "wayland" or "WAYLAND_DISPLAY" in os.environ


def is_x11() -> bool:
    return not is_wayland() and ("DISPLAY" in os.environ or os.environ.get("XDG_SESSION_TYPE", "").lower() == "x11")


class X11DesktopDocker:
    """
    Direct X11 EWMH desktop docking via ctypes libX11.
    Sets _NET_WM_WINDOW_TYPE_DESKTOP and _NET_WM_STATE_BELOW so the window
    docks permanently behind desktop icons and other windows without decorations.
    """

    def __init__(self):
        self._libx11 = None
        self._display = None
        self._initialized = False

        if not is_x11():
            return

        try:
            # Look for libX11.so
            for name in ["libX11.so.6", "libX11.so", "libX11.so.6.4.0"]:
                try:
                    self._libx11 = ctypes.cdll.LoadLibrary(name)
                    break
                except OSError:
                    continue

            if self._libx11:
                # Declare C types
                self._libx11.XOpenDisplay.restype = ctypes.c_void_p
                self._libx11.XOpenDisplay.argtypes = [ctypes.c_char_p]
                self._libx11.XCloseDisplay.argtypes = [ctypes.c_void_p]

                self._libx11.XInternAtom.restype = ctypes.c_ulong
                self._libx11.XInternAtom.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]

                self._libx11.XChangeProperty.argtypes = [
                    ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong,
                    ctypes.c_int, ctypes.c_int, ctypes.c_void_p, ctypes.c_int
                ]
                self._libx11.XLowerWindow.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
                self._libx11.XFlush.argtypes = [ctypes.c_void_p]

                self._display = self._libx11.XOpenDisplay(None)
                if self._display:
                    self._initialized = True
                    logger.info("X11 desktop docking subsystem initialized successfully.")
        except Exception as e:
            logger.warning(f"Could not initialize X11 ctypes library: {e}")

    def dock_window(self, win_id: int, bounds: tuple = None) -> bool:
        if not self._initialized or not self._display:
            return False

        try:
            display = self._display
            xwin = ctypes.c_ulong(win_id)

            # 1. Set _NET_WM_WINDOW_TYPE to _NET_WM_WINDOW_TYPE_DESKTOP
            atom_type = self._libx11.XInternAtom(display, b"_NET_WM_WINDOW_TYPE", 0)
            atom_desktop = self._libx11.XInternAtom(display, b"_NET_WM_WINDOW_TYPE_DESKTOP", 0)
            desktop_val = (ctypes.c_ulong * 1)(atom_desktop)
            self._libx11.XChangeProperty(
                display, xwin, atom_type, ctypes.c_ulong(4), 32, 0,
                ctypes.cast(desktop_val, ctypes.c_void_p), 1
            )

            # 2. Set _NET_WM_STATE to include BELOW, STICKY, SKIP_TASKBAR, SKIP_PAGER
            atom_state = self._libx11.XInternAtom(display, b"_NET_WM_STATE", 0)
            atom_below = self._libx11.XInternAtom(display, b"_NET_WM_STATE_BELOW", 0)
            atom_sticky = self._libx11.XInternAtom(display, b"_NET_WM_STATE_STICKY", 0)
            atom_skip_tb = self._libx11.XInternAtom(display, b"_NET_WM_STATE_SKIP_TASKBAR", 0)
            atom_skip_pg = self._libx11.XInternAtom(display, b"_NET_WM_STATE_SKIP_PAGER", 0)

            states = (ctypes.c_ulong * 4)(atom_below, atom_sticky, atom_skip_tb, atom_skip_pg)
            self._libx11.XChangeProperty(
                display, xwin, atom_state, ctypes.c_ulong(4), 32, 0,
                ctypes.cast(states, ctypes.c_void_p), 4
            )

            # 3. Lower the window to the bottom of the window stack
            self._libx11.XLowerWindow(display, xwin)
            self._libx11.XFlush(display)

            logger.info(f"Successfully docked X11 window {win_id} as Desktop wallpaper.")
            return True
        except Exception as e:
            logger.error(f"Error docking X11 window {win_id}: {e}")
            return False

    def close(self):
        if self._display and self._libx11:
            try:
                self._libx11.XCloseDisplay(self._display)
            except Exception:
                pass
            self._display = None


def apply_desktop_window_hints(widget, mode: str = "wallpaper"):
    """
    Applies Qt window flags and attributes for desktop, widget, or fullscreen mode.
    """
    try:
        from PyQt6.QtCore import Qt
    except ImportError:
        try:
            from PySide6.QtCore import Qt
        except ImportError:
            return

    if mode == "wallpaper":
        # Borderless, stays on bottom, no taskbar, tool window
        flags = (
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnBottomHint |
            Qt.WindowType.SubWindow
        )
        widget.setWindowFlags(flags)
        # Enable X11 Desktop type attribute if Qt supports it
        if hasattr(Qt.WidgetAttribute, "WA_X11NetWmWindowTypeDesktop"):
            widget.setAttribute(Qt.WidgetAttribute.WA_X11NetWmWindowTypeDesktop, True)
        widget.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
    elif mode == "fullscreen":
        widget.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        widget.showFullScreen()
    elif mode == "windowed":
        widget.setWindowFlags(Qt.WindowType.Window)
