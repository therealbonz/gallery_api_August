"""
My-3D-Cube: Linux Client & Live Desktop Wallpaper
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A dynamic 3D spinning cube live desktop wallpaper and interactive companion
for Linux desktop environments (X11 & Wayland).
"""

__version__ = "1.0.0"
__author__ = "bonz"
__license__ = "MIT"
