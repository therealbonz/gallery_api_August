# My-3D-Cube: Linux Client & Live Desktop Wallpaper

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Platform: Linux](https://img.shields.io/badge/Platform-Linux%20(X11%20%7C%20Wayland)-green.svg)]()
[![Python: 3.9+](https://img.shields.io/badge/Python-3.9+-yellow.svg)]()
[![Backend: Rails API](https://img.shields.io/badge/API-Rails%207-red.svg)](http://162.35.101.183:3000)

A high-performance, dynamic 3D spinning cube live desktop wallpaper and interactive companion client for Linux desktop environments (X11 & Wayland), syncing automatically with the **My-3D-Cube** media platform.

---

## ✨ Features

- **Behind-The-Icons Live Wallpaper**:
  - Docks directly to the desktop root behind all desktop icons, selection boxes, and open windows via X11 EWMH (`_NET_WM_WINDOW_TYPE_DESKTOP` & `_NET_WM_STATE_BELOW`).
  - Supports XFCE, KDE Plasma, MATE, Cinnamon, Openbox, i3, and GNOME (X11 & Wayland).
- **Interactive Companion Widget Mode**:
  - Resizable and draggable floating companion window with real-time mouse drag rotation and zoom.
- **Fullscreen & Screensaver Mode**:
  - Borderless fullscreen display for living room screens, multi-monitor kiosks, or visual ambiance.
- **Multi-Monitor Display Management**:
  - Automatically detects all active displays (`QApplication.screens()`) and spawns coordinated 3D cubes with unique media assignments per monitor.
- **PulseAudio & PipeWire Audio Loopback Visualizer**:
  - Real-time audio reactive visualizer ring that pulses to music playing on Spotify, YouTube, VLC, and games using native Linux audio monitors (`parec`).
- **FreeDesktop System Tray & AppIndicator**:
  - 🔄 **Refresh Media**: Force immediate synchronization with the Rails API.
  - 🌐 **Open Web Gallery**: Launches the web gallery in your default Linux browser (`xdg-open`).
  - ⏯️ **Pause / Resume Rotation**: Toggle continuous spin.
  - ⚡ **Rotation Speed**: Slow (0.4x), Normal (0.8x), Fast (1.6x).
  - 🌤️ **Weather Overlays**: Live Auto Weather, Clear, Rain, Snow, Clouds, Thunderstorm.
  - 🎵 **Audio Visualizer**: Off, Pulse Beat, Desktop Loopback, Microphone.
  - 🪟 **Window Mode**: Desktop Wallpaper, Floating Widget, Fullscreen.
  - 🚀 **Start with Linux**: Toggle autostart desktop entry (`~/.config/autostart/`).
  - ❌ **Clean Exit**: Releases all X11 handles and audio streams.
- **Chrome Extension Video Casting (WebRTC)**:
  - Built-in **LocalStreamBridge** HTTP server on `http://127.0.0.1:48124` compatible with the My-3D-Cube Chrome extension to cast YouTube, Twitch, or screen shares directly onto cube faces.
- **Offline Fallback Player**:
  - Includes a bundled offline WebGL player so the 3D cube continues spinning smoothly even when disconnected from the network.

---

## 🚀 Quick Start (Automated Installation)

Clone the repository and run the automated installer:

```bash
git clone https://github.com/therealbonz/gallery_linux_August.git
cd gallery_linux_August
chmod +x install.sh
./install.sh
```

The installer will:
1. Set up an isolated Python environment in `~/.local/share/my3dcube/venv`.
2. Install required QtWebEngine dependencies.
3. Install the executable into `~/.local/bin/my3dcube`.
4. Register the application with your desktop menu (`~/.local/share/applications/my3dcube.desktop`).
5. Install high-resolution desktop and system tray icons.

---

## 💻 Manual Installation by Distribution

### 1. Ubuntu / Debian / Linux Mint / Pop!_OS
```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv pulseaudio-utils libx11-6
pip install -r requirements.txt
pip install -e .
```

### 2. Fedora / RHEL
```bash
sudo dnf install -y python3 python3-pip pulseaudio-utils libX11
pip install -r requirements.txt
pip install -e .
```

### 3. Arch Linux / Manjaro
```bash
sudo pacman -S --needed python python-pip pulseaudio libx11
pip install -r requirements.txt
pip install -e .
```

---

## 🕹️ CLI Usage & Flags

```bash
# Launch as background live wallpaper behind desktop icons (default)
my3dcube --wallpaper

# Launch as a floating, resizable interactive companion widget
my3dcube --windowed

# Launch in fullscreen screensaver mode
my3dcube --fullscreen

# Span wallpaper across ALL connected monitors
my3dcube --all-monitors

# Target a specific monitor index (e.g. secondary monitor)
my3dcube --monitor 1

# Connect to a custom My-3D-Cube server URL
my3dcube --url http://192.168.1.50:5173

# Set initial rotation speed: 0.4 (slow), 0.8 (normal), 1.6 (fast)
my3dcube --speed 1.6

# Set active weather effect (auto, clear, rain, snow, clouds, storm)
my3dcube --weather rain

# Enable PulseAudio/PipeWire system audio loopback visualizer
my3dcube --audio-mode system

# Launch using local offline bundled WebGL player
my3dcube --offline

# Run headless WebRTC LocalStreamBridge for Chrome Extension without GUI
my3dcube --headless-bridge
```

---

## ⚙️ Systemd Background Service

To run My-3D-Cube automatically as a managed background user service on login:

```bash
# Enable and start the service
systemctl --user enable --now my3dcube.service

# Check status
systemctl --user status my3dcube.service

# Stop service
systemctl --user stop my3dcube.service
```

---

## 📂 Project Structure

```
gallery_linux_August/
├── assets/
│   └── icons/
│       └── my3dcube.svg           # High-resolution vector 3D cube icon
├── my3dcube/
│   ├── __init__.py                # Package version and metadata
│   ├── app.py                     # Central application lifecycle & IPC
│   ├── audio_capture.py           # PulseAudio/PipeWire monitor audio engine
│   ├── autostart.py               # FreeDesktop autostart manager
│   ├── config.py                  # Persistent JSON configuration (~/.config/my3dcube/)
│   ├── desktop_hook.py            # X11 EWMH & Wayland desktop docking
│   ├── main.py                    # Command-line interface entrypoint
│   ├── offline_player/
│   │   └── index.html             # Bundled offline WebGL Three.js 3D player
│   ├── stream_bridge.py           # LocalStreamBridge server (:48124) for Chrome casting
│   ├── tray.py                    # FreeDesktop StatusNotifierItem system tray
│   └── wallpaper_window.py        # Hardware-accelerated QtWebEngine window
├── install.sh                     # One-click installation script
├── uninstall.sh                   # Clean uninstallation script
├── my3dcube.desktop               # FreeDesktop application entry
├── my3dcube.service               # Systemd user background service
├── pyproject.toml                 # Standard packaging metadata
├── requirements.txt               # Dependencies
├── setup.py                       # Setuptools installer
├── LICENSE                        # MIT License
└── README.md                      # Documentation
```

---

## 🗑️ Uninstallation

To cleanly remove My-3D-Cube from your system:

```bash
./uninstall.sh
```

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).
